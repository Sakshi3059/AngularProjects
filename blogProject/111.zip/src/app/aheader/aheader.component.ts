import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-aheader',
  templateUrl: './aheader.component.html',
  styleUrls: ['./aheader.component.css']
})


export class AheaderComponent implements OnInit {
  active_route;
  constructor(private act_ro:ActivatedRoute) { }

  ngOnInit() {
 this.active_route="hii";
 this.active_route=this.act_ro.snapshot.params.active_route;
 alert(this.active_route);
  }

}
