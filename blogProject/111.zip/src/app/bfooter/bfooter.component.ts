import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfooter',
  templateUrl: './bfooter.component.html',
  styleUrls: ['./bfooter.component.css']
})
export class BfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
