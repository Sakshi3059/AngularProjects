import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acategory',
  templateUrl: './acategory.component.html',
  styleUrls: ['./acategory.component.css']
})
export class AcategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
