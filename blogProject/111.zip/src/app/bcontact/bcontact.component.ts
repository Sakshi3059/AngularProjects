import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bcontact',
  templateUrl: './bcontact.component.html',
  styleUrls: ['./bcontact.component.css']
})
export class BcontactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
