import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AheaderComponent } from './aheader/aheader.component';
import { AfooterComponent } from './afooter/afooter.component';
import { AcategoryComponent } from './acategory/acategory.component';
import { AblogComponent } from './ablog/ablog.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AdashbComponent } from './adashb/adashb.component';
import { AdminComponent } from './admin/admin.component';
import {AloginComponent} from  './alogin/alogin.component';
import { AlogService } from './alog.service';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoggGuard } from './logg.guard';
import { BheaderComponent } from './bheader/bheader.component';
import { BhomeComponent } from './bhome/bhome.component';
import { BfooterComponent } from './bfooter/bfooter.component';
import { BcategoryComponent } from './bcategory/bcategory.component';
import { BaboutComponent } from './babout/babout.component';
import { BcontactComponent } from './bcontact/bcontact.component';
import {SiteComponent} from './site/site.component';


const r:Routes=[  

                  {path:'',component:AppComponent,
                   children:[
                    {path:'',redirectTo:'site',pathMatch:'full'},
                    {path:'admin',component:AdminComponent,
                    children:[
                        {path:'',redirectTo:'alogin',pathMatch:'full'},
                        {path:'alogin',component:AloginComponent},
                        {path:'welcome',component:WelcomeComponent},
                        {path:'adash',component:AdashbComponent,canActivate:[LoggGuard],
                          children:[ 
                            {path:'',redirectTo:'acategory',pathMatch:'full'},
                            {path:'acategory',component:AcategoryComponent},
                            {path:'ablog',component:AblogComponent},
                            {path:'feedback',component:FeedbackComponent},
                          ]
                          },
                        
                        ]},
                     {path:'site',component:SiteComponent,
                       children:[
                             {path:'',redirectTo:'bhome',pathMatch:'full'},
                             {path:'bhome',component:BhomeComponent},
                             {path:'babout',component:BaboutComponent},
                             {path:'bcategory',component:BcategoryComponent},
                             {path:'bcontact',component:BcontactComponent}
                       ]}
            
                   ]}
              
               ];
@NgModule({
  declarations: [
    AppComponent,
    AheaderComponent,
    AfooterComponent,
    AcategoryComponent,
    AblogComponent,
    FeedbackComponent,
    AdashbComponent,
    AdminComponent,
    AloginComponent,
    WelcomeComponent,
    BheaderComponent,
    BhomeComponent,
    BfooterComponent,
    BcategoryComponent,
    BaboutComponent,
    BcontactComponent,
    SiteComponent,
    
  ],

  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,RouterModule.forRoot(r),
  ],
  providers: [AlogService,LoggGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
