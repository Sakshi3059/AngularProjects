import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bhome',
  templateUrl: './bhome.component.html',
  styleUrls: ['./bhome.component.css']
})
export class BhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
