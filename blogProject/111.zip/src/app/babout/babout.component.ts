import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-babout',
  templateUrl: './babout.component.html',
  styleUrls: ['./babout.component.css']
})
export class BaboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
