import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bcategory',
  templateUrl: './bcategory.component.html',
  styleUrls: ['./bcategory.component.css']
})
export class BcategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
