import { Component, OnInit } from '@angular/core';
import {AlogService} from '../alog.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-alogin',
  templateUrl: './alogin.component.html',
  styleUrls: ['./alogin.component.css']
})
export class AloginComponent implements OnInit {
 uname;
 pwd;
  constructor(private ser:AlogService,private ro:Router) { 
    this.uname="";
    this.pwd="";
  }
login()
{
  if(this.uname=="admin" && this.pwd=="password")
     {
       this.ser.set();
       this.ro.navigateByUrl('/admin/welcome')
     }

      else
      {
        alert("wrong credetniALS")
        this.ro.navigateByUrl('/admin/alogin')
      }

}
  ngOnInit() {
  }

}
