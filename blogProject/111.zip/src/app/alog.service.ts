import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AlogService {
 flag:boolean;
  constructor() { }
  set()
  {this.flag=true;}
   get()
   {return this.flag}
}
