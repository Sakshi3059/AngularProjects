import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bheader',
  templateUrl: './bheader.component.html',
  styleUrls: ['./bheader.component.css']
})
export class BheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
