import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ablog',
  templateUrl: './ablog.component.html',
  styleUrls: ['./ablog.component.css']
})
export class AblogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
